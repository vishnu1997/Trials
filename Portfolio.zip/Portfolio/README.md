# Portfolio
This portfolio website project is created as a part of Udacity Full Stack Web Developer Course.

## How to view the web-page
 Extract the zip file and open index.html in a browser.


